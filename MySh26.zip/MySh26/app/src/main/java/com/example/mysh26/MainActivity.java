package com.example.mysh26;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView GradeCalculator =findViewById(R.id.textView);
        TextView Result =findViewById(R.id.textView2);
        Button calculate =findViewById(R.id.button);
        EditText editText =findViewById(R.id.editText);
        EditText editTextone =findViewById(R.id.editTextone);
        EditText editTextTaxt =findViewById(R.id.editTextText);
        EditText editTextTwo =findViewById(R.id.editTaxtTwo);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               int num1 =Integer.parseInt(editText.getText().toString());
               int num2 =Integer.parseInt(editTextone.getText().toString());
               int num3 =Integer.parseInt(editTextTaxt.getText().toString());
               int num4 =Integer.parseInt(editTextTwo.getText().toString());

               int result = num1 + num2 + num3 + num4;

               Result.setText(String.valueOf(result));





            }
        });













    }
}